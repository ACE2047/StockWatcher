package com.seproject.springboot_stockwatcher;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootStockwatcherApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootStockwatcherApplication.class, args);
	}



}
