package com.seproject.springboot_stockwatcher;

import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import java.util.List;
import java.util.ArrayList;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Map;
import java.util.HashMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;



@CrossOrigin(origins = "http://localhost:63342")
@RestController
@RequestMapping("/api")
public class UserController {

    @Autowired
    private UserService userService;

    // endpoint to handle user registration
    @PostMapping("/register")
    public ResponseEntity<String> registerUser(@RequestBody User user) {
        String result = userService.createAccount(user); //call userService to create account
        if ("success".equals(result)) {
            return ResponseEntity.ok("Account created successfully."); // success response
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(result); // if some test error, found on tutorial
        }
    }

    // endpoint that handles user login
    @PostMapping("/login")
    public ResponseEntity<Map<String, Object>> loginUser(@RequestBody UserLoginRequest loginRequest) {
        int userID = userService.getUserID(loginRequest.getEmail(), loginRequest.getPassword()); // validates user
        if (userID != -1) {
            // testing feature
            Map<String, Object> response = new HashMap<>();
            response.put("message", "Login successful.");
            response.put("userID", userID); // return userID in response
            return ResponseEntity.ok(response);
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null); //more test error stuff
        }
    }

    // endpoint to add a stock to user watchlist
    @PostMapping("/addToWatchlist")
    public ResponseEntity<String> addToWatchlist(@RequestBody Map<String, Object> requestData) {
        try {
            Integer userID = (Integer) requestData.get("userID");
            String ticker = (String) requestData.get("ticker");

            // testing feature. check if both userID and ticker are there
            if (userID == null || ticker == null || ticker.isEmpty()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid userID or ticker.");
            }

            boolean added = userService.addToWatchlist(userID, ticker);
            if (added) {
                return ResponseEntity.ok("Stock added to watchlist."); // add stock to watchlist
            } else {
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to add stock to watchlist."); //testing
            }
        } catch (Exception e) {
            e.printStackTrace(); //log exception, testing stuff
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("An error occurred."); //more test errors
        }
    }

    // endpoint to remove stock from user watchlist
    @CrossOrigin(origins = "http://localhost:63342")
    @PostMapping("/removeFromWatchlist")
    public ResponseEntity<String> removeFromWatchlist(@RequestBody Map<String, Object> requestData) {
        try {
            // Retrieve userID as a String and convert to Integer
            String userIdString = (String) requestData.get("userID"); //convert userID from string to int
            Integer userID = Integer.parseInt(userIdString);
            String ticker = (String) requestData.get("ticker");

            //validate input
            if (userID == null || ticker == null || ticker.isEmpty()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid userID or ticker.");
            }

            boolean removed = userService.removeFromWatchlist(userID, ticker); // remove stock from watchlist
            if (removed) {
                return ResponseEntity.ok("Stock removed from watchlist.");
            } else {
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to remove stock from watchlist.");
            }
        } catch (Exception e) {
            e.printStackTrace(); //log exception, testing stuff
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("An error occurred."); //more testing errors
        }
    }

    // endpoint to retrieve all stocks
    @GetMapping("/stocks")
    public ResponseEntity<List<StockData>> getAllStocks(@RequestParam String date) {
        List<StockData> stocks = userService.getAllStocks(date); //fetch stocks for certain date
        if (stocks != null) {
            return ResponseEntity.ok(stocks); // return stocks
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null); //testing errors
        }
    }

    // endpoint to search for stocks on stock list
    @GetMapping("/stocks/search")
    public ResponseEntity<List<StockData>> searchStocks(
            @RequestParam String query,
            @RequestParam String date) {
        List<StockData> stocks = userService.searchStocks(query, date); //search for matching stocks
        return ResponseEntity.ok(stocks); //return search results
    }

    // endpoint to retrieve users watchlist
    @GetMapping("/watchlist")
    public ResponseEntity<List<StockData>> getWatchlist(
            @RequestParam int userID,
            @RequestParam String date) {
        List<StockData> watchlistStocks = userService.getUserWatchlist(userID, date); //fetch watchlist
        if (watchlistStocks != null) {
            return ResponseEntity.ok(watchlistStocks); //return watchlist
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null); //testing errors
        }
    }

    // endpoint to search user watchlist
    @GetMapping("/watchlist/search")
    public ResponseEntity<List<StockData>> searchUserWatchlist(
            @RequestParam int userID,
            @RequestParam String query,
            @RequestParam String date) {
        List<StockData> watchlistStocks = userService.searchWatchlist(userID, query, date); //search watchlist
        return ResponseEntity.ok(watchlistStocks); // return search results
    }

}

