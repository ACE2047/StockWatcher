// initialize dates for stock data
let currentDate = '2023-01-01';
const dates = ['2023-01-01', '2023-02-01', '2023-03-01'];
let dateIndex = 0; // index current date
let currentSearchQuery = ''; // stores user search

// handle register submission
document.getElementById('registerForm').addEventListener('submit', function(event) {
    event.preventDefault();

    // create user object from user input
    const user = {
        username: document.getElementById('username').value,
        email: document.getElementById('email').value,
        password: document.getElementById('password').value
    };

    // sends POST request to /register
    fetch('http://localhost:8080/api/register', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json' //specify its a json
        },
        body: JSON.stringify(user) // convert user to a json string
    })
    .then(response => response.text()) // parse response as text
    .then(data => {
        alert(data); // display message to user
        if (data === "Account created successfully.") {
            window.location.href = 'login.html'; // direct to login page when they register
        }
    })
    .catch(error => console.error('Error:', error)); // log errors
});


// Logs user out, takes them to login page
function logout() {
    window.location.href = 'login.html';
}

// update watchlist page
function updateWatchlistTable(watchlistStocks) {
    const watchlistTableBody = document.querySelector('#watchlistTable tbody');
    watchlistTableBody.innerHTML = ""; // clear past data

    // repeat over stocks in watchlist
    watchlistStocks.forEach(stock => {
        const row = document.createElement('tr');
        row.setAttribute('data-ticker', stock.ticker); // add stock ticker as an attribute
        row.innerHTML = `
            <td>${stock.ticker}</td>
            <td>${stock.date}</td>
            <td>$${stock.openPrice}</td>
            <td>$${stock.closePrice}</td>
            <td>$${stock.highPrice}</td>
            <td>$${stock.lowPrice}</td>
            <td><button class="remove-button" onclick="removeFromWatchlist('${stock.ticker}')">-</button></td>
        `;
        watchlistTableBody.appendChild(row); // add row to table
    });
}

// handle user login (valid login)
function performLogin() {
    const email = document.getElementById('email').value; // get email input
    const password = document.getElementById('password').value; // get password input

    const loginRequest = {
        email: email,
        password: password
    };

    // send request to /login
    fetch('http://localhost:8080/api/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json' // specify its a json
        },
        body: JSON.stringify(loginRequest) //convert request to json string
    })
    .then(response => {
        if (response.ok) {
            return response.json(); // parse response as json if success
        } else {
            throw new Error("Invalid Email/Password."); // handle invalid login
        }
    })
    .then(data => {
        if (data.userID) { // check if userID exists in the response data
            sessionStorage.setItem("userID", data.userID); // store userID in sessionStorage
            window.location.href = 'stocklist.html'; // direct to stock list page
        }
    })
    .catch(error => {
        alert(error.message); // show error alert on invalid login
        console.error('Error:', error);
    });
}

// update stock table with stock data
function updateStockTable(stocks) {
    const stockTableBody = document.querySelector('#stockTable tbody');
    stockTableBody.innerHTML = "";  // clear previous data

    stocks.forEach(stock => {
        const row = document.createElement('tr');
        const isInWatchlist = userWatchlist.has(stock.ticker); // check if stock in user watchlist

        row.innerHTML = `
            <td>${stock.ticker}</td>
            <td>${stock.date}</td>
            <td>$${stock.openPrice}</td>
            <td>$${stock.closePrice}</td>
            <td>$${stock.highPrice}</td>
            <td>$${stock.lowPrice}</td>
            <td>
                ${isInWatchlist
                    ? `<button class="add-button disabled" disabled></button>`  // empty disabled button
                    : `<button class="add-button" onclick="addToWatchlist('${stock.ticker}')">+</button>`
                }
            </td>
        `;
        stockTableBody.appendChild(row); //add row to table
    });
}

// add stock to user watchlist
function addToWatchlist(ticker) {
    const userID = parseInt(sessionStorage.getItem("userID"));

    if (!userID) {
        alert("User not logged in.");
        return;
    }

    fetch('http://localhost:8080/api/addToWatchlist', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ userID, ticker }) //send userID/ticker as json
    })
    .then(response => response.text())
    .then(() => {
        userWatchlist.add(ticker); //add stock to watchlist
        const button = document.querySelector(`#stockTable button[onclick="addToWatchlist('${ticker}')"]`);
        if (button) {
            button.classList.add('disabled'); //disable add button, prevent selecting when already in watchlist
            button.disabled = true;
            button.innerHTML = ''; // clear + button
        }
    })
    .catch(error => console.error('Error:', error));
}

// remove stock from user's watchlist
function removeFromWatchlist(ticker) {
    const userID = sessionStorage.getItem("userID");

    fetch('http://localhost:8080/api/removeFromWatchlist', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ userID, ticker }) //send userID/ticker as json
    })
    .then(response => {
        if (response.ok) {
            const row = document.querySelector(`#watchlistTable tr[data-ticker="${ticker}"]`);
            if (row) {
                row.remove(); // remove stock row
            }
        } else {
            throw new Error("Failed to remove stock from watchlist.");
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
}

// update stock data
function updateStockData() {
    dateIndex = (dateIndex + 1) % dates.length; // cycles through dates array in a loop
    currentDate = dates[dateIndex]; // update current date to next

    // update both stock list and watchlist if they exist on the page
    if (document.getElementById('stockTable')) {
        loadStockData();
    }
    if (document.getElementById('watchlistTable')) {
        loadWatchlist();
    }
}

// loads stock data
function loadStockData() {
    loadUserWatchlist() // loads user watchlist before fetching stock data
        .then(() => {
            // fetch stock data four current date
            return fetch(`http://localhost:8080/api/stocks?date=${currentDate}`);
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Failed to load stocks'); //response error in case
            }
            return response.json(); // parse response as json
        })
        .then(stocks => {
            updateStockTable(stocks); // update stock table with obtained data
        })
        .catch(error => console.error('Error loading stocks:', error)); // log errors
}

// load user watchlist
function loadWatchlist() {
    const userID = sessionStorage.getItem("userID"); // get the UserID from session storage

    if (!userID) {
        alert("User not logged in."); // in case, alert user they not logged in (test feature tbh, wont ever be used)
        return;
    }

    // fetch watchlist data for current user and current date stocks
    fetch(`http://localhost:8080/api/watchlist?userID=${userID}&date=${currentDate}`)
        .then(response => response.json()) //parse response as json
        .then(watchlistStocks => {
            updateWatchlistTable(watchlistStocks); //update watchlist table with data
        })
        .catch(error => console.error('Error loading watchlist:', error)); // log errors
}

// searches for stocks from user search query
function searchStocks(query) {
    const encodedQuery = encodeURIComponent(query); //encoded, saw it on a tutorial
    const url = `http://localhost:8080/api/stocks/search?query=${encodedQuery}&date=${currentDate}`;

    // fetch search results
    fetch(url)
        .then(response => response.json()) // parse response as json
        .then(stocks => {
            updateStockTable(stocks); //update stock table with search results
        })
        .catch(error => console.error('Error searching stocks:', error)); //log errors
}

function searchWatchlist(query) {
    const userID = sessionStorage.getItem("userID"); //get userID from session storage
    if (!userID) {
        console.error("User not logged in."); // testing feature to check if logged in
        alert("User not logged in.");
        return;
    }

    const encodedQuery = encodeURIComponent(query); //encode the query, tutorial did it
    const url = `http://localhost:8080/api/watchlist/search?userID=${userID}&query=${encodedQuery}&date=${currentDate}`;

    //fetch search results
    fetch(url)
        .then(response => response.json()) // parse response as json
        .then(watchlistStocks => {
            updateWatchlistTable(watchlistStocks); //update the watchlist with search results
        })
        .catch(error => console.error('Error searching watchlist:', error));
}

// loads user watchlist
function loadUserWatchlist() {
    const userID = sessionStorage.getItem("userID"); //retrieve UserID session storage

    // from user watchlist data
    return fetch(`http://localhost:8080/api/watchlist?userID=${userID}&date=${currentDate}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Failed to load user watchlist'); // handle any response errors
            }
            return response.json(); //parse as json
        })
        .then(watchlistStocks => {
            // store the watchlist as set of tickers for quick lookup
            userWatchlist = new Set(watchlistStocks.map(stock => stock.ticker));
        })
        .catch(error => console.error('Error loading user watchlist:', error)); // log errors
}

