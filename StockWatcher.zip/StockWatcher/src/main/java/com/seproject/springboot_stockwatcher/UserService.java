package com.seproject.springboot_stockwatcher;

import org.springframework.stereotype.Service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.ArrayList;
import java.math.BigDecimal;
import java.util.Date;


@Service
public class UserService {
    // database connection stuff, change this to your system yall
    private static final String DB_URL = "jdbc:mysql://localhost:3306/StockWatcher";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "d1502@sn0w!#*";

    // create new accounts
    public String createAccount(User user) {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            // check if username/email already exists
            if (isUsernameOrEmailExists(conn, user.getUsername(), user.getEmail())) {
                return "Username/Email already in use.";
            }

            // sql query, insert new user into database
            String sql = "INSERT INTO User (Username, Email, Password) VALUES (?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, user.getUsername());
                stmt.setString(2, user.getEmail());
                stmt.setString(3, user.getPassword());
                stmt.executeUpdate(); // execute query
                return "success"; // return message if successful
            }
        } catch (SQLException e) {
            return "Error creating account."; // testing
        }
    }

    // checks if user info is valid to login
    public boolean login(String email, String password) {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            // sql query check if email and password match
            String sql = "SELECT * FROM User WHERE Email = ? AND Password = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, email);
                stmt.setString(2, password);
                ResultSet rs = stmt.executeQuery(); // execute
                return rs.next(); // return true if match found
            }
        } catch (SQLException e) {
            return false; // testing. return false if nothing found
        }
    }

    // check if username or email already being used
    private boolean isUsernameOrEmailExists(Connection conn, String username, String email) throws SQLException {
        String sql = "SELECT * FROM User WHERE Username = ? OR Email = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, username);
            stmt.setString(2, email);
            ResultSet rs = stmt.executeQuery();
            return rs.next(); // return true if found
        }
    }

    // add stocks to user watchlist
    public boolean addToWatchlist(int userID, String ticker) {
        String sql = "INSERT INTO Watchlist (UserID, ticker) VALUES (?, ?)";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, userID);
            stmt.setString(2, ticker);
            stmt.executeUpdate(); // executes aka adds
            return true;

        } catch (SQLException e) {
            e.printStackTrace(); // testing log stuff
            return false;
        }
    }

    // retrieve userID based on email and password
    public int getUserID(String email, String password) {
        String sql = "SELECT UserID FROM User WHERE Email = ? AND Password = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, email);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getInt("UserID"); //return userID if match is found
            }
        } catch (SQLException e) {
            e.printStackTrace(); //testing testing
        }
        return -1; // return -1 if the user is not found
    }

    // remove stock from user watchlist
    public boolean removeFromWatchlist(int userID, String ticker) {
        String sql = "DELETE FROM Watchlist WHERE UserID = ? AND ticker = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, userID);
            stmt.setString(2, ticker);
            int rowsAffected = stmt.executeUpdate(); //execute
            return rowsAffected > 0; // return true if rows were deleted

        } catch (SQLException e) {
            e.printStackTrace(); // testing stuff
            return false;
        }
    }

    // fetch all stock data with certain date
    public List<StockData> getAllStocks(String date) {
        List<StockData> stocks = new ArrayList<>();
        String sql = "SELECT * FROM StockData WHERE date = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, date);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                StockData stock = new StockData();
                stock.setTicker(rs.getString("ticker"));
                stock.setDate(rs.getDate("date"));
                stock.setOpenPrice(rs.getBigDecimal("open_price"));
                stock.setClosePrice(rs.getBigDecimal("close_price"));
                stock.setHighPrice(rs.getBigDecimal("high_price"));
                stock.setLowPrice(rs.getBigDecimal("low_price"));
                stocks.add(stock); // add stock
            }
        } catch (SQLException e) {
            e.printStackTrace(); //testing
        }
        return stocks; // return list of stocks
    }

    // method to fetch user watchlist for certain dates
    public List<StockData> getUserWatchlist(int userID, String date) {
        List<StockData> watchlistStocks = new ArrayList<>();
        String sql = "SELECT s.ticker, s.date, s.open_price, s.close_price, s.high_price, s.low_price " +
                "FROM StockData s JOIN Watchlist w ON s.ticker = w.ticker " +
                "WHERE w.UserID = ? AND s.date = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, userID);
            stmt.setString(2, date);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                StockData stock = new StockData();
                stock.setTicker(rs.getString("ticker"));
                stock.setDate(rs.getDate("date"));
                stock.setOpenPrice(rs.getBigDecimal("open_price"));
                stock.setClosePrice(rs.getBigDecimal("close_price"));
                stock.setHighPrice(rs.getBigDecimal("high_price"));
                stock.setLowPrice(rs.getBigDecimal("low_price"));
                watchlistStocks.add(stock); // adds stock to watchlist
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return watchlistStocks; // return user watchlist
    }

    // search for stocks
    public List<StockData> searchStocks(String query, String date) {
        List<StockData> stocks = new ArrayList<>();
        String sql = "SELECT * FROM StockData WHERE ticker LIKE ? AND date = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, query + "%");
            stmt.setString(2, date);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                StockData stock = new StockData();
                stock.setTicker(rs.getString("ticker"));
                stock.setDate(rs.getDate("date"));
                stock.setOpenPrice(rs.getBigDecimal("open_price"));
                stock.setClosePrice(rs.getBigDecimal("close_price"));
                stock.setHighPrice(rs.getBigDecimal("high_price"));
                stock.setLowPrice(rs.getBigDecimal("low_price"));
                stocks.add(stock); // add matching stocks to list
            }
        } catch (SQLException e) {
            e.printStackTrace(); // testing
        }
        return stocks; // return search results
    }

    // search for stocks on user watchlist
    public List<StockData> searchWatchlist(int userID, String query, String date) {
        List<StockData> stocks = new ArrayList<>();
        String sql = "SELECT s.ticker, s.date, s.open_price, s.close_price, s.high_price, s.low_price " +
                "FROM StockData s JOIN Watchlist w ON s.ticker = w.ticker " +
                "WHERE w.UserID = ? AND s.ticker LIKE ? AND s.date = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, userID);
            stmt.setString(2, query + "%");
            stmt.setString(3, date);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                StockData stock = new StockData();
                stock.setTicker(rs.getString("ticker"));
                stock.setDate(rs.getDate("date"));
                stock.setOpenPrice(rs.getBigDecimal("open_price"));
                stock.setClosePrice(rs.getBigDecimal("close_price"));
                stock.setHighPrice(rs.getBigDecimal("high_price"));
                stock.setLowPrice(rs.getBigDecimal("low_price"));
                stocks.add(stock); // adds matching stocks to list
            }
        } catch (SQLException e) {
            e.printStackTrace(); // testing
        }
        return stocks; // return search results
    }

}

