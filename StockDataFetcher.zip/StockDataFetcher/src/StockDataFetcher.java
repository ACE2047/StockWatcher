import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.concurrent.TimeUnit;
import org.json.JSONArray;
import org.json.JSONObject;

public class StockDataFetcher {

    private static final String API_KEY = "8Cpzjn8wGC0fwvyshVj2UNM2lC4frpif";
    private static final String DB_URL = "jdbc:mysql://localhost:3306/StockWatcher";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "d1502@sn0w!#*";
    private static final String[] TICKERS = {"AAPL", "META", "NFLX", "AMZN", "GOOGL", "NVDA", "AMD", "MSFT", "TSLA", "INTC",
                                            "BA", "JPM", "WMT", "DIS", "V", "JNJ", "XOM", "BAC", "KO", "CSCO",
                                            "PEP", "NKE", "ORCL", "IBM", "GE", "PFE", "MRK", "ABT", "LLY", "MCD",
                                            "UPS", "UNH", "T", "CVX", "ADBE", "PYPL", "CRM", "QCOM", "SBUX", "MO",
                                            "SPGI", "CAT", "LMT", "MMM", "DOW", "GS", "F", "GM", "FDX", "COST",
                                            "LOW", "KHC", "BK", "BLK", "AXP", "SO", "D", "CL", "TGT", "C",
                                            "APD", "AMAT", "MDT", "TMO", "COP", "NEE", "DUK", "RTX", "ZTS", "SCHW",
                                            "PSX", "BDX", "PLD", "DE", "TJX", "EMR", "USB", "EBAY", "AIG", "ADI",
                                            "HCA", "STZ", "CSX", "EOG", "ICE", "SYK", "MS", "ADI", "A", "GM",
                                            "BKNG", "GILD", "ISRG", "MDLZ", "REGN", "DHR", "SYY", "VZ", "MET", "ETN",
                                            "FIS", "AFL", "ALL", "ATVI", "EA", "SPG", "O", "BMY", "CME", "KMB"};
    private static final String START_DATE = "2023-01-01";
    private static final String END_DATE = "2023-03-01";

    public static void main(String[] args) {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            for (String ticker : TICKERS) {
                System.out.println("Fetching data for " + ticker);
                String stockData = getStockData(ticker, START_DATE, END_DATE);
                if (stockData != null) {
                    saveStockDataToDB(conn, ticker, stockData);
                }
                TimeUnit.SECONDS.sleep(5); // delay to avoid hitting limit
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static String getStockData(String ticker, String startDate, String endDate) {
        String urlString = String.format(
                "https://api.polygon.io/v2/aggs/ticker/%s/range/1/month/%s/%s?adjusted=true&sort=asc&limit=100&apiKey=%s",
                ticker, startDate, endDate, API_KEY);

        try {
            URL url = new URL(urlString);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");

            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder content = new StringBuilder();
                String inputLine;
                while ((inputLine = in.readLine()) != null) {
                    content.append(inputLine);
                }
                in.close();
                return content.toString();
            } else if (responseCode == 429) {
                System.out.println("Rate limit reached. Waiting one minute.");
                TimeUnit.SECONDS.sleep(60); // retry after a minute
                return getStockData(ticker, startDate, endDate);
            } else {
                System.out.println("Error: " + responseCode + " - " + connection.getResponseMessage());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private static void saveStockDataToDB(Connection conn, String ticker, String stockData) {
        try {
            JSONObject json = new JSONObject(stockData);
            JSONArray results = json.getJSONArray("results");

            String sql = "INSERT INTO StockData (ticker, date, open_price, close_price, high_price, low_price) " +
                    "VALUES (?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE open_price = VALUES(open_price), " +
                    "close_price = VALUES(close_price), high_price = VALUES(high_price), low_price = VALUES(low_price)";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                for (int i = 0; i < results.length(); i++) {
                    JSONObject dayData = results.getJSONObject(i);
                    stmt.setString(1, ticker);
                    stmt.setDate(2, new java.sql.Date(dayData.getLong("t")));
                    stmt.setDouble(3, dayData.getDouble("o"));
                    stmt.setDouble(4, dayData.getDouble("c"));
                    stmt.setDouble(5, dayData.getDouble("h"));
                    stmt.setDouble(6, dayData.getDouble("l"));
                    stmt.executeUpdate();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

